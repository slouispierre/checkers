﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ChexBoard : MonoBehaviour
{
    public static ChexBoard Instance { set; get; }

    public Pieces[,] pieces = new Pieces[8, 8];
    public GameObject WhitePiecePrefab;
    public GameObject BlackPiecePrefab;

    public CanvasGroup alertCanvas;

    public Vector3 boardOffset = new Vector3(-4.0f, 0, -4.0f);
    public Vector3 pieceOffset = new Vector3(0.5f, 0, 0.5f);

    public bool isWhite;
    private bool isWhiteTurn;
    private bool hasJumped;
    private bool gameOver;
    private bool alertActive;

    private float lastAlert;
    private float winTime;

    private Pieces selectedPiece;
    private List<Pieces> forcedPieces;

    public Vector2 cursorPosition;
    private Vector2 startDrag;
    private Vector2 destinationDrag;

    private Client client;

    private void Start()
    {
        Instance = this;
        client = FindObjectOfType<Client>();
        //isWhite = client.isHost;

        if (client)
        {
            isWhite = client.isHost;
            Alert(client.players[0].name + " VS " + client.players[1].name);
        }
        else
        {
            Alert("White player's turn");
        }

        isWhiteTurn = true;
        forcedPieces = new List<Pieces>();
        GenerateBoard();
    }

    private void Update()
    {
        if (gameOver)
        {
            if (Time.time - winTime > 3.0f)
            {
                Server server = FindObjectOfType<Server>();
                Client client = FindObjectOfType<Client>();

                if (server)
                    Destroy(server.gameObject);

                if (client)
                    Destroy(client.gameObject);

                SceneManager.LoadScene("Menu");
            }
            return;
        }

        UpdateAlert();
        updateCursorPosition();
        //Debug.Log(cursorPosition);

        // If my turn
        if ((isWhite) ? isWhiteTurn : !isWhiteTurn)

        {
            int x = (int)cursorPosition.x;
            int y = (int)cursorPosition.y;

            // Live update of where piece is being dragged
            if (selectedPiece != null)
                UpdatePieceDrag(selectedPiece);

            // selecting piece to drag and drop
            if (Input.GetMouseButtonDown(0))
                SelectPiece(x, y);

            if (Input.GetMouseButtonUp(0))
                AttemptMove((int)startDrag.x, (int)startDrag.y, x, y);
        }
    }

    public void AttemptMove(int x1, int y1, int x2, int y2)
    {
        // check if move is forced, i.e. a jump
        forcedPieces = ScanForMoves();

        //Multiplay Support
        startDrag = new Vector2(x1, y1);
        destinationDrag = new Vector2(x2, y2);
        selectedPiece = pieces[x1, y1];

        //MovePieces(selectedPiece, x2, y2);

        // check to make sure if in bounds
        if (x2 < 0 || x2 >= 8 || y2 < 0 || y2 >= 8)
        {
            // return piece to original position
            if (selectedPiece != null)
                MovePieces(selectedPiece, x1, y1);

            startDrag = Vector2.zero;
            selectedPiece = null;
            return;
        }

        // check piece selected or if destination is same as origin 
        if (selectedPiece != null)
        {
            if (destinationDrag == startDrag)
            {
                MovePieces(selectedPiece, x1, y1);
                startDrag = Vector2.zero;
                selectedPiece = null;
                return;
            }

            // check if going in right direction or valid move
            if (selectedPiece.ValidMove(pieces, x1, y1, x2, y2))
            {
                // check if move is a jump
                if (Mathf.Abs(x2 - x1) == 2)
                {
                    Pieces p = pieces[(x1 + x2) / 2, (y1 + y2) / 2];
                    if (p != null)
                    {
                        pieces[(x1 + x2) / 2, (y1 + y2) / 2] = null;
                        DestroyImmediate(p.gameObject);
                        hasJumped = true;
                    }
                }

                // Were we supposed to jump?
                // check to make sure if jump was neccessary
                // that piece was jumped, other wise
                // it was an invalid move (block other piece from moving)
                if (forcedPieces.Count != 0 && !hasJumped)
                {
                    MovePieces(selectedPiece, x1, y1);
                    startDrag = Vector2.zero;
                    selectedPiece = null;
                    return;
                }

                // if not return to origin
                pieces[x2, y2] = selectedPiece;
                pieces[x1, y1] = null;
                MovePieces(selectedPiece, x2, y2);

                EndTurn();
            }
            else
            {
                // if move invalid, return to original position
                MovePieces(selectedPiece, x1, y1);
                startDrag = Vector2.zero;
                selectedPiece = null;
                return;
            }
        }
    }

    private void EndTurn()
    {
        int x = (int)destinationDrag.x;
        int y = (int)destinationDrag.y;

        // King Me! 
        if (selectedPiece != null)
        {
            if (selectedPiece.isWhite && !selectedPiece.isKing && y == 7)
            {
                selectedPiece.isKing = true;
                selectedPiece.transform.Rotate(Vector3.right * 180);
            }
            else if (!selectedPiece.isWhite && !selectedPiece.isKing && y == 0)
            {
                selectedPiece.isKing = true;
                selectedPiece.transform.Rotate(Vector3.right * 180);
            }
        }

        // create msg to send client's move to server
        string msg = "CMOV|";
        msg += startDrag.x.ToString() + "|";
        msg += startDrag.y.ToString() + "|";
        msg += destinationDrag.x.ToString() + "|";
        msg += destinationDrag.y.ToString();

        client.Send(msg);

        selectedPiece = null;
        startDrag = Vector2.zero;

        // allow for double or triple jumps
        if (ScanForMoves(selectedPiece, x, y).Count != 0 && hasJumped)
            return;

        isWhiteTurn = !isWhiteTurn;
        hasJumped = false;
        checkWinner();
    }

    private void checkWinner()
    {
        // which player no longer has any pieces?
        var ps = FindObjectsOfType<Pieces>();
        bool hasWhite = false, hasBlack = false;
        for (int i = 0; i < ps.Length; i++)
        {
            if (ps[i].isWhite)
                hasWhite = true;
            else
                hasBlack = true;
        }

        if (!hasWhite)
            Winner(false);
        if (!hasBlack)
            Winner(true);
    }

    private void Winner(bool isWhite)
    {
        winTime = Time.time;

        if (isWhite)
            Alert("White has won the game!");
        else
            Alert("Black has won the game!");

        gameOver = true;
    }

    private List<Pieces> ScanForMoves(Pieces p, int x, int y)
    {
        // forced jumps in specified double/triple jump scenario
        forcedPieces = new List<Pieces>();

        if (pieces[x, y].ForceJump(pieces, x, y))
            forcedPieces.Add(pieces[x, y]);

        return forcedPieces;
    }

    private List<Pieces> ScanForMoves()
    {
        forcedPieces = new List<Pieces>();
        // check all pieces to see if jump required
        for (int i = 0; i < 8; i++)
            for (int j = 0; j < 8; j++)
                if (pieces[i, j] != null && pieces[i, j].isWhite == isWhiteTurn)
                    if (pieces[i, j].ForceJump(pieces, i, j))
                        forcedPieces.Add(pieces[i, j]);

        return forcedPieces;
    }


    private void updateCursorPosition()
    {
        if (!Camera.main)
        {
            Debug.Log("Unable to find main camera");
            return;
        }

        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("ChexBoard")))
        {
            cursorPosition.x = (int)(hit.point.x - boardOffset.x); // determining mouse x-corrdinates
            cursorPosition.y = (int)(hit.point.z - boardOffset.z); // determining mouse y-coordinates
        }
        else
        {
            cursorPosition.x = -1;
            cursorPosition.y = -1;
        }
    }

    private void UpdatePieceDrag(Pieces p)
    {
        if (!Camera.main)
        {
            Debug.Log("Unable to find main camera");
            return;
        }

        RaycastHit hit;
        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, 25.0f, LayerMask.GetMask("ChexBoard")))
        {
            p.transform.position = hit.point + Vector3.up;
        }
    }

    private void SelectPiece(int x, int y)
    {
        // if out of bounds
        if (x < 0 || x >= 8 || y < 0 || y >= 8)
            return;

        Pieces p = pieces[x, y];
        if (p != null && p.isWhite == isWhite)
        {
            // check if forced move is required
            if (forcedPieces.Count == 0)
            {
                selectedPiece = p;
                startDrag = cursorPosition;
                //Debug.Log(selectedPiece.name);
            }
            else
            {
                // check if selected piece is forced piece
                if (forcedPieces.Find(fp => fp == p) == null)
                    return;

                selectedPiece = p;
                startDrag = cursorPosition;
                //Debug.Log(selectedPiece.name);
            }
        }
    }

    private void GenerateBoard()
    {
        //Generate white pieces
        for (int y = 0; y < 3; y++) // three rows of pieces
        {
            bool oddRow = (y % 2 == 0); //check if odd row for piece pootioning
            for (int x = 0; x < 8; x += 2) // skip space every piece
            {
                GeneratePieces((oddRow) ? x : x + 1, y); // if row is odd, shift piece by 1
            }
        }

        //Generate black pieces
        for (int y = 7; y > 4; y--) // three rows of pieces
        {
            bool oddRow = (y % 2 == 0); //check if odd row for piece pootioning
            for (int x = 0; x < 8; x += 2) // skip space every piece
            {
                GeneratePieces((oddRow) ? x : x + 1, y); // if row is odd, shift piece by 1
            }
        }
    }


    private void GeneratePieces(int x, int y)
    {
        bool isPieceWhite = (y > 3) ? false : true; //if y is less than three than white, else black
        GameObject go = Instantiate((isPieceWhite) ? WhitePiecePrefab : BlackPiecePrefab) as GameObject;
        go.transform.SetParent(transform);
        Pieces p = go.GetComponent<Pieces>();
        pieces[x, y] = p;
        MovePieces(p, x, y);
    }

    private void MovePieces(Pieces p, int x, int y)
    {
        p.transform.position = (Vector3.right * x) + (Vector3.forward * y) + boardOffset + pieceOffset;
    }

    public void Alert(string msg)
    {
        alertCanvas.GetComponentInChildren<Text>().text = msg;
        lastAlert = Time.time;
        alertActive = true;
    }

    public void UpdateAlert()
    {
        if (alertActive)
        {
            if (Time.time - lastAlert > 0.5f)
            {
                alertCanvas.alpha = 1 - ((Time.time - lastAlert) - 2.5f);

                if (Time.time - lastAlert > 4.5f)
                {
                    alertActive = false;
                }
            }
        }
    }

}
