﻿using UnityEngine;
using System.Collections;

public class Pieces : MonoBehaviour
{
    public bool isWhite;
    public bool isKing;

    public bool ForceJump(Pieces[,] board, int x, int y)
    {
        if (isWhite || isKing)
        {
            //edge case : Top Left
            if (x >= 2 && y <= 5)
            {
                Pieces p = board[x - 1, y + 1];
                // If there is a piece, and it is not the same color
                if (p != null && p.isWhite != isWhite)
                {
                    // check if possible to land jump
                    if (board[x - 2, y + 2] == null)
                        return true;
                }
            }

            //edge case : Top Right
            if (x <= 2 && y <= 5)
            {
                Pieces p = board[x + 1, y + 1];
                // If there is a piece, and it is not the same color
                if (p != null && p.isWhite != isWhite)
                {
                    // check if possible to land jump
                    if (board[x + 2, y + 2] == null)
                        return true;
                }
            }
        }

        if (!isWhite || isKing)
        {
            //edge case : Bottom Left
            if (x >= 2 && y >= 2)
            {
                Pieces p = board[x - 1, y - 1];
                // If there is a piece, and it is not the same color
                if (p != null && p.isWhite != isWhite)
                {
                    // check if possible to land jump
                    if (board[x - 2, y - 2] == null)
                        return true;
                }
            }

            //edge case : Bottom Right
            if (x <= 5 && y >= 2)
            {
                Pieces p = board[x + 1, y - 1];
                // If there is a piece, and it is not the same color
                if (p != null && p.isWhite != isWhite)
                {
                    // check if possible to land jump
                    if (board[x + 2, y - 2] == null)
                        return true;
                }
            }
        }

        return false;
    }

    public bool ValidMove(Pieces[,] board, int x1, int y1, int x2, int y2)
    {
        // if you are moving on top of another piece
        if (board[x2, y2] != null)
            return false;

        // if you are moving a white piece
        int deltaMoveX = Mathf.Abs(x1 - x2);
        int deltaMoveY = y2 - y1;
        if (isWhite || isKing)
        {
            // check if moving a single space in right direction 
            if (deltaMoveX == 1)
            {
                if (deltaMoveY == 1)
                    return true;
            }
            // check if move is a jump
            else if (deltaMoveX == 2)
            {
                if (deltaMoveY == 2)
                {
                    Pieces p = board[(x1 + x2) / 2, (y1 + y2) / 2];
                    if (p != null && p.isWhite != isWhite)
                        return true;
                }
            }
        }

        // do the same thing for moving black pieces
        if (!isWhite || isKing)
        {
            if (deltaMoveX == 1)
            {
                if (deltaMoveY == -1)
                    return true;
            }
            else if (deltaMoveX == 2)
            {
                if (deltaMoveY == -2)
                {
                    Pieces p = board[(x1 + x2) / 2, (y1 + y2) / 2];
                    if (p != null && p.isWhite != isWhite)
                        return true;
                }
            }
        }

        return false;
    }
}
